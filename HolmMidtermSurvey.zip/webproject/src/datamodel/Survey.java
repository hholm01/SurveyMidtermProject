package datamodel;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @since J2SE-1.8
 CREATE TABLE survey (
  id INT NOT NULL AUTO_INCREMENT,    
  userName VARCHAR(30) NOT NULL,
  major VARCHAR(30) NOT NULL,
  food VARCHAR(30) NOT NULL,
  cook VARCHAR(30) NOT NULL,
  pet VARCHAR(30) NOT NULL,
  PRIMARY KEY (id));
 */
@Entity
@Table(name = "survey")
public class Survey {

   @Id  // primary key
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   @Column(name = "id") // specify the column name. Without it, it will use method name
   private Integer id;

   @Column(name = "userName")
   private String userName;

   @Column(name = "major")
   private String major;
   
   @Column(name = "food")
   private String food;
   
   @Column(name = "cook")
   private String cook;
   
   @Column(name = "pet")
   private String pet;

   public Survey() {
   }

   public Survey(Integer id, String userName, String major, String food, String cook, String pet) {
      this.id = id;
      this.userName = userName;
      this.major = major;
      this.food = food;
      this.cook = cook;
      this.pet = pet;
   }

   public Survey(String userName, String major, String food, String cook, String pet) {
      this.userName = userName;
      this.major = major;
      this.food = food;
      this.cook = cook;
      this.pet = pet;
   }

   public Integer getId() {
      return id;
   }

   public void setId(Integer id) {
      this.id = id;
   }

   public String getuserName() {
      return userName;
   }

   public void setuserName(String userName) {
      this.userName = userName;
   }
   
   public String getmajor() {
	   return major;
   }

   public void setmajor(String major) {
	   this.major = major;
   }
   
   public String getfood() {
	   return food;
   }

   public void setfood(String food) {
	   this.food = food;
   }
   
   public String getcook() {
	   return major;
   }

   public void setcook(String cook) {
	   this.cook = cook;
   }
   
   public String getpet() {
	   return pet;
   }

   public void setpet(String pet) {
	   this.pet = pet;
   }
   
	   

   @Override
   public String toString() {
      return this.id + ", " + this.userName + ", " + this.major + ", " + this.food + ", " + this.cook + ", " + this.pet;
   }
}