package util;

public interface Info {
   public String projectName = "webproject";
   public String searchWebName = "simpleSearchHB.html";
   public String insertWebName = "simpleInsertHB.html";
}
